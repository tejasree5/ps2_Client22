import React from 'react'

const IndianRecipes = () => {
  return (
    <div>
      <h1>have  a wonderfull meal style={{color:'red'}}</h1>
    </div>
  )
}

export default IndianRecipes;
